var questions = [
{
	"question id" : "1",
    "answer id" : "a1",
    "answer": "dependent & y-axis"
},

{
	"question id" : "2",
    "answer id" : "a2",
    "answer": "independent & x-axis"
},

{
	"question id" : "3",
    "answer id" : "a3",
    "answer": "dependent & x-axis"
},

{
	"question id" : "4",
    "answer id" : "a4",
    "answer": "independent & y-axis"
},

{
	"question id" : "5",
    "answer id" : "a5",
    "answer": "None of the above"
},


];

var slides_info = {
    "hint": "Go back and read about Types of Data:Graphs!"
}